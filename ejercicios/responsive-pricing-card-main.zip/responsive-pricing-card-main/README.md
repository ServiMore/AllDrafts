# Responsive Pricing Card
## [Watch it on youtube](https://youtu.be/jE0A0w_jnf4)
### Responsive Pricing Card
Beautiful responsive ui cards using HTML & CSS.

Don't forget to join the channel for more videos like this. [Bedimcode](https://www.youtube.com/c/Bedimcode)

![Pricing card](/preview.png)
