﻿namespace JuegoBarca {
    internal enum Tipo {

        Vegetal,
        Carnivoro,
        Herbivoro,
        Barca,
        NA

    }
}
