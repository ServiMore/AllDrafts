﻿namespace JuegoBarca {
    public enum Zona {

        Izquierda,
        Derecha

    }
}
