﻿namespace Entities {
    public class Product {

        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public double Precio { get; set; }

    }
}
